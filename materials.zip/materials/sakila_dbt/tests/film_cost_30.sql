select
*
from
dwh.film_test
where replacement_cost > 29
