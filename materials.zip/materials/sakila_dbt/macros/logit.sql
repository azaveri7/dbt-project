{% macro logit(arg1) %}

    {{ log("Running some_stuff: " ~ arg1 ) }}

{% endmacro %}
